
DELIMITER $$

CREATE TRIGGER after_update_pedido_compra
AFTER UPDATE ON RG_PedidoCompra
FOR EACH ROW
BEGIN
    -- Variables para iteración
    DECLARE entrada_id INT;
    DECLARE entrada_producto INT;
    DECLARE entrada_ingrediente INT;
    DECLARE entrada_cantidad INT;
    DECLARE entrada_costo DECIMAL(10, 2);
    DECLARE finished INT DEFAULT 0;

    -- Saldo previo en el Kardex
    DECLARE cur_saldoCantidad INT;
    DECLARE cur_saldoValor DECIMAL(10, 2);

    -- Cursor para seleccionar entradas relacionadas al pedido de compra
    DECLARE entradaCursor CURSOR FOR
    SELECT 
        E.idEntrada, 
        E.idProducto, 
        E.idIngrediente, 
        E.cantidadEntrada, 
        E.costoUnitarioEntrada
    FROM RG_Entrada E
    INNER JOIN RG_Compra C ON C.idCompra = E.idCompra
    WHERE C.idDetallePedidoProducto IN (
        SELECT idDetallePedidoProducto 
        FROM RG_DetallePedidoProducto 
        WHERE idPedidoCompra = NEW.idPedidoCompra
    )
    OR C.idDetallePedidoIngrediente IN (
        SELECT idDetallePedidoIngrediente 
        FROM RG_DetallePedidoIngrediente 
        WHERE idPedidoCompra = NEW.idPedidoCompra
    );

    -- Handler para detectar el fin del cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    -- Solo proceder si el estado cambia a "Pagada"
    IF NEW.estadoPedidoCompra = 'Pagada' AND OLD.estadoPedidoCompra != 'Pagada' THEN
        -- Abrir el cursor
        OPEN entradaCursor;

        -- Iterar sobre las entradas seleccionadas
        entrada_loop: LOOP
            FETCH entradaCursor INTO entrada_id, entrada_producto, entrada_ingrediente, entrada_cantidad, entrada_costo;

            -- Salir del loop si no hay más filas
            IF finished = 1 THEN
                LEAVE entrada_loop;
            END IF;

            -- Procesar producto (si aplica)
            IF entrada_producto IS NOT NULL THEN
                SELECT saldoCantidadKardex, saldoValorKardex
                INTO cur_saldoCantidad, cur_saldoValor
                FROM RG_Kardex
                WHERE idProducto = entrada_producto
                ORDER BY fechaMovimientoKardex DESC, idKardex DESC
                LIMIT 1;

                INSERT INTO RG_Kardex (
                    idProducto, 
                    fechaMovimientoKardex, 
                    cantidadKardex, 
                    costoUnitarioKardex, 
                    saldoCantidadKardex, 
                    saldoValorKardex, 
                    idEntrada
                ) VALUES (
                    entrada_producto, 
                    NOW(), 
                    entrada_cantidad, 
                    entrada_costo, 
                    IFNULL(cur_saldoCantidad, 0) + entrada_cantidad, 
                    IFNULL(cur_saldoValor, 0) + (entrada_cantidad * entrada_costo), 
                    entrada_id
                );
            END IF;

            -- Procesar ingrediente (si aplica)
            IF entrada_ingrediente IS NOT NULL THEN
                SELECT saldoCantidadKardex, saldoValorKardex
                INTO cur_saldoCantidad, cur_saldoValor
                FROM RG_Kardex
                WHERE idIngrediente = entrada_ingrediente
                ORDER BY fechaMovimientoKardex DESC, idKardex DESC
                LIMIT 1;

                INSERT INTO RG_Kardex (
                    idIngrediente, 
                    fechaMovimientoKardex, 
                    cantidadKardex, 
                    costoUnitarioKardex, 
                    saldoCantidadKardex, 
                    saldoValorKardex, 
                    idEntrada
                ) VALUES (
                    entrada_ingrediente, 
                    NOW(), 
                    entrada_cantidad, 
                    entrada_costo, 
                    IFNULL(cur_saldoCantidad, 0) + entrada_cantidad, 
                    IFNULL(cur_saldoValor, 0) + (entrada_cantidad * entrada_costo), 
                    entrada_id
                );
            END IF;

        END LOOP;

        -- Cerrar el cursor
        CLOSE entradaCursor;
    END IF;
END$$

DELIMITER ;

DELIMITER $$

CREATE TRIGGER after_orden_update_estado
AFTER UPDATE ON RG_Orden
FOR EACH ROW
BEGIN
    -- Declarar variables
    DECLARE salida_id INT;
    DECLARE salida_producto INT;
    DECLARE salida_cantidad INT;
    DECLARE salida_costo DECIMAL(10, 2);
    DECLARE currentSaldoCantidad INT DEFAULT 0;
    DECLARE currentSaldoValor DECIMAL(10, 2) DEFAULT 0.00;

    -- Cursor para iterar sobre las salidas relacionadas con la orden
    DECLARE salidaCursor CURSOR FOR
    SELECT 
        S.idSalida, S.idProducto, S.cantidadSalida, S.costoUnitarioSalida
    FROM RG_Salida S
    JOIN RG_DetalleVenta DV ON S.idProducto = DV.idProducto
    WHERE DV.idOrden = NEW.idOrden
    ORDER BY S.idSalida;

    -- Handler para cuando no haya más filas
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET salida_id = NULL;

    -- Comenzar la lógica del trigger
    IF NEW.estadoOrden = 'Pagada' AND OLD.estadoOrden != 'Pagada' THEN
        OPEN salidaCursor;

        salida_loop: LOOP
            FETCH salidaCursor INTO salida_id, salida_producto, salida_cantidad, salida_costo;

            -- Salir del loop si no hay más filas
            IF salida_id IS NULL THEN
                LEAVE salida_loop;
            END IF;

            -- Verificar si la salida ya está registrada en el Kardex
            IF NOT EXISTS (
                SELECT 1 
                FROM RG_Kardex
                WHERE idSalida = salida_id
            ) THEN
                -- Obtener el saldo más reciente del producto desde la tabla Kardex
                SELECT saldoCantidadKardex, saldoValorKardex
                INTO currentSaldoCantidad, currentSaldoValor
                FROM RG_Kardex
                WHERE idProducto = salida_producto
                ORDER BY fechaMovimientoKardex DESC, idKardex DESC
                LIMIT 1;

                -- Validar que haya suficiente stock para la salida
                IF currentSaldoCantidad < salida_cantidad THEN
                    SIGNAL SQLSTATE '45000' 
                    SET MESSAGE_TEXT = 'Saldo insuficiente para realizar la salida';
                ELSE
                    -- Insertar un nuevo registro en Kardex para la salida
                    INSERT INTO RG_Kardex (
                        idProducto,
                        fechaMovimientoKardex,
                        cantidadKardex,
                        costoUnitarioKardex,
                        saldoCantidadKardex,
                        saldoValorKardex,
                        idSalida
                    )
                    VALUES (
                        salida_producto,
                        NOW(),
                        -salida_cantidad,  -- Negativo para reflejar la salida
                        salida_costo,
                        currentSaldoCantidad - salida_cantidad,  -- Nuevo saldo cantidad
                        currentSaldoValor - (salida_cantidad * salida_costo),  -- Nuevo saldo valor
                        salida_id
                    );
                END IF;
            END IF;
        END LOOP;

        CLOSE salidaCursor;
    END IF;
END$$

DELIMITER ;

DELIMITER $$

CREATE TRIGGER after_salida_insert_ingrediente
AFTER INSERT ON RG_Salida
FOR EACH ROW
BEGIN
    -- Verificar que la salida esté asociada a un ingrediente
    IF NEW.idIngrediente IS NOT NULL THEN
        -- Declarar variables mediante variables de usuario
        SET @saldo_cantidad = (
            SELECT saldoCantidadKardex
            FROM RG_Kardex
            WHERE idIngrediente = NEW.idIngrediente
            ORDER BY fechaMovimientoKardex DESC, idKardex DESC
            LIMIT 1
        );

        SET @saldo_valor = (
            SELECT saldoValorKardex
            FROM RG_Kardex
            WHERE idIngrediente = NEW.idIngrediente
            ORDER BY fechaMovimientoKardex DESC, idKardex DESC
            LIMIT 1
        );

        -- Inicializar saldos si no hay registro previo
        IF @saldo_cantidad IS NULL THEN
            SET @saldo_cantidad = 0;
            SET @saldo_valor = 0.00;
        END IF;

        -- Validar que el saldo no sea negativo
        IF @saldo_cantidad - NEW.cantidadSalida < 0 THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Error: El saldo en el Kardex para este ingrediente no puede ser negativo.';
        END IF;

        -- Calcular el nuevo saldo
        SET @saldo_cantidad = @saldo_cantidad - NEW.cantidadSalida;
        SET @saldo_valor = @saldo_valor - (NEW.cantidadSalida * NEW.costoUnitarioSalida);

        -- Insertar el movimiento en el Kardex
        INSERT INTO RG_Kardex (
            idIngrediente,
            fechaMovimientoKardex,
            cantidadKardex,
            costoUnitarioKardex,
            saldoCantidadKardex,
            saldoValorKardex
        ) VALUES (
            NEW.idIngrediente,
            NEW.fechaSalida,
            NEW.cantidadSalida,
            NEW.costoUnitarioSalida,
            @saldo_cantidad,
            @saldo_valor
        );
    END IF;
END$$

DELIMITER ;
